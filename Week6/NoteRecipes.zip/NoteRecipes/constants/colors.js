//Set the color to use on the code
const Colors = {
  accent500: "#e8a156",
  accent800: "#a16a2e",
  primary300: "#ffffff",
  primary500: "#db7248",
  primary800: "#873312",
};

export default Colors;
